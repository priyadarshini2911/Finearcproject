﻿$(document).ready(function () {
    $('.cnctdetails').animate(
        { deg: 360 },
        {
            duration: 1200,
            step: function (now) {
                $(this).css({ transform: 'rotate(' + now + 'deg)' });
            }
        });
    $("#btnsubmit").click(function () {
        var nametxt = $('#name');
        var emailtxt = $('#email');
        var messtxt = $('#mess');
        if (nametxt.val() != "" && emailtxt.val() != "" && messtxt.val() != "") {
            alert('Thank You! For Your FeedBack Visit Again!!!');
        }
        else {
            alert("Please Enter Details");
        }
    });
});



$("#btnsubmit").click(function () {
    alert("Thank you ! For Your FeedBack.Visit Again!!!")
});
