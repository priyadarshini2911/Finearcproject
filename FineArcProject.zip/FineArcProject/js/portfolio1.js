﻿$(document).ready(function () {
    setInterval(function () {
        $('.divrows').fadeIn(3000).delay(3000);
        $('#img1').fadeOut(3000).delay(2000).fadeIn(2500);
        $('#img2').fadeOut(4000).delay(2500).fadeIn(3500);
        $('#img3').fadeOut(5000).delay(3000).fadeIn(4500);
        $('#img4').fadeOut(6000).delay(3500).fadeIn(5500);
        $('#img5').fadeOut(7000).delay(4000).fadeIn(6500);
        $('#img6').fadeOut(8000).delay(4500).fadeIn(7500);
    })
});